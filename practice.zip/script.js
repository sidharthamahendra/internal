console.log("Hello from the script!");
